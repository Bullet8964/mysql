# 教學用模擬銷售資料 MySQL 與 Python 數據分析專案

本專案完整依照 README 要求實作：
1. **MySQL 資料結構建置** (`schema.sql`)
2. **資料匯入與完整快照更新管道** (`pipeline.py`)
   - 匯入 original.csv (300筆)
   - 依 `sale_id` 更新為 updated.csv 快照 (維持300筆，240筆異動、60筆不變)
   - 前三種商品每筆銷量增加8件，第7至10種商品每筆增加3件，藍牙耳機每筆退貨增加1件
   - 嚴格數值斷言驗收 (Assertions)
3. **靜態網頁產生器** (`generate_static_page.py`)
   - 依據規範：「更新MySQL後須重新執行Python並更新靜態網頁，GitHub Pages不會直接查詢MySQL。」
   - 自動產生含有折線圖、長條圖、圓餅圖、通路比較與散佈圖的 `index.html`，可直接推送到 GitHub Pages。
4. **Python Web 伺服器** (`app.py`)
   - 使用 Flask 建立 MySQL Web 網頁介面，支援 SQL 執行與資料視覺化。

---

## 驗收數值規範與比對

| 指標 | 原始 (Original) | 更新後 (Updated) | 驗收狀態 |
| :--- | :---: | :---: | :---: |
| **總筆數 (records)** | 300 | 300 | 通過 (不串接為600筆) |
| **總銷量 (quantity)** | 3,444 | 4,524 | 通過 (+1,080件) |
| **退貨數 (returns)** | 33 | 63 | 通過 (+30件) |
| **淨銷售額 (netRevenue)** | NT$ 3,217,100 | NT$ 3,970,100 | 通過 (+NT$ 753,000) |
| **異動筆數 (changed)** | - | 240 筆 (60筆不變) | 通過 |

---

## 快速開始

### 1. 安裝 Python 套件
```bash
pip install -r requirements.txt
```

### 2. 初始化 MySQL 並執行 Pipeline
```bash
# 建立資料庫與資料表
mysql -u root -p < schema.sql

# 執行匯入、快照更新與驗收檢驗
python pipeline.py
```

### 3. 產出 GitHub Pages 靜態網頁
```bash
python generate_static_page.py
# 產出 index.html，即可推送到 GitHub 倉庫開啟 GitHub Pages
```

### 4. 啟動 Python Web 介面
```bash
python app.py
# 開啟瀏覽器訪問 http://127.0.0.1:5000
```
