-- ========================================================
-- 教學用模擬銷售資料 MySQL 資料表結構定義
-- ========================================================

CREATE DATABASE IF NOT EXISTS sales_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE sales_db;

DROP TABLE IF EXISTS sales;

CREATE TABLE sales (
    sale_id INT PRIMARY KEY COMMENT '紀錄主鍵 (1-300)',
    sale_date DATE NOT NULL COMMENT '銷售日期 (2026-09-01 至 2026-09-30)',
    product_id INT NOT NULL COMMENT '商品編號 (1-10)',
    product_name VARCHAR(100) NOT NULL COMMENT '商品名稱',
    category VARCHAR(50) NOT NULL COMMENT '商品分類',
    channel VARCHAR(50) NOT NULL COMMENT '銷售通路 (實體門市/網路商店/校園團購)',
    unit_price INT NOT NULL COMMENT '單價 (新臺幣)',
    quantity INT NOT NULL COMMENT '售出數量 (含退貨)',
    returned_quantity INT NOT NULL COMMENT '退貨數量',
    -- 淨銷售額以虛擬計算欄位或預先計算儲存: unit_price * (quantity - returned_quantity)
    net_revenue INT GENERATED ALWAYS AS (unit_price * (quantity - returned_quantity)) STORED COMMENT '淨銷售額',
    INDEX idx_sale_date (sale_date),
    INDEX idx_product_id (product_id),
    INDEX idx_category (category),
    INDEX idx_channel (channel)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='2026年9月銷售明細快照資料表';
