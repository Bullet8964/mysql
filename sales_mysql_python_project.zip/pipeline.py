#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
教學用模擬銷售資料 - MySQL 資料匯入、快照更新與驗收管道
依據 README 規範：
  1. 匯入 original.csv (300筆)
  2. 驗收 original 指標 (records:300, quantity:3444, returns:33, netRevenue:3217100)
  3. 依據 sale_id 更新為 updated.csv 完整快照 (維持300筆，240筆異動、60筆不變)
  4. 驗收 updated 指標 (records:300, quantity:4524, returns:63, netRevenue:3970100)
"""

import csv
import os
import sys
import mysql.connector
from mysql.connector import Error

# 資料庫連線配置 (請依據您的 MySQL 環境修改)
DB_CONFIG = {
    'host': os.getenv('MYSQL_HOST', 'localhost'),
    'port': int(os.getenv('MYSQL_PORT', 3306)),
    'user': os.getenv('MYSQL_USER', 'root'),
    'password': os.getenv('MYSQL_PASSWORD', 'rootpassword'),
    'database': os.getenv('MYSQL_DATABASE', 'sales_db'),
    'charset': 'utf8mb4'
}

EXPECTED_ORIGINAL = {
    "records": 300,
    "quantity": 3444,
    "returns": 33,
    "netRevenue": 3217100
}

EXPECTED_UPDATED = {
    "records": 300,
    "quantity": 4524,
    "returns": 63,
    "netRevenue": 3970100,
    "changed": 240
}

def get_connection():
    return mysql.connector.connect(**DB_CONFIG)

def init_table(cursor):
    """建立或重置 sales 資料表"""
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS sales (
            sale_id INT PRIMARY KEY,
            sale_date DATE NOT NULL,
            product_id INT NOT NULL,
            product_name VARCHAR(100) NOT NULL,
            category VARCHAR(50) NOT NULL,
            channel VARCHAR(50) NOT NULL,
            unit_price INT NOT NULL,
            quantity INT NOT NULL,
            returned_quantity INT NOT NULL,
            net_revenue INT GENERATED ALWAYS AS (unit_price * (quantity - returned_quantity)) STORED,
            INDEX idx_sale_date (sale_date),
            INDEX idx_product_id (product_id),
            INDEX idx_category (category),
            INDEX idx_channel (channel)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    """)

def load_csv(filepath):
    """讀取 CSV 檔案 (支援 UTF-8 BOM)"""
    records = []
    with open(filepath, mode='r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            records.append({
                'sale_id': int(row['sale_id']),
                'sale_date': row['sale_date'],
                'product_id': int(row['product_id']),
                'product_name': row['product_name'],
                'category': row['category'],
                'channel': row['channel'],
                'unit_price': int(row['unit_price']),
                'quantity': int(row['quantity']),
                'returned_quantity': int(row['returned_quantity'])
            })
    return records

def import_original_data(cursor, records):
    """匯入 original 資料 (清空後批次寫入)"""
    print("[1/4] 清空並匯入原始銷售資料 (300筆)...")
    cursor.execute("TRUNCATE TABLE sales;")
    insert_sql = """
        INSERT INTO sales 
        (sale_id, sale_date, product_id, product_name, category, channel, unit_price, quantity, returned_quantity)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
    """
    data = [
        (
            r['sale_id'], r['sale_date'], r['product_id'], r['product_name'],
            r['category'], r['channel'], r['unit_price'], r['quantity'], r['returned_quantity']
        )
        for r in records
    ]
    cursor.executemany(insert_sql, data)

def query_stats(cursor):
    """查詢當前資料表的彙總驗收指標"""
    cursor.execute("""
        SELECT 
            COUNT(*) AS total_records,
            COALESCE(SUM(quantity), 0) AS total_quantity,
            COALESCE(SUM(returned_quantity), 0) AS total_returns,
            COALESCE(SUM(net_revenue), 0) AS total_net_revenue
        FROM sales;
    """)
    row = cursor.fetchone()
    return {
        "records": int(row[0]),
        "quantity": int(row[1]),
        "returns": int(row[2]),
        "netRevenue": int(row[3])
    }

def update_snapshot(cursor, updated_records):
    """
    依 sale_id 更新為 updated 完整快照。
    不可串接為 600 筆，更新後仍為 300 筆。
    同時統計異動筆數 (共 240 筆異動、60 筆不變)。
    """
    print("[3/4] 依據 sale_id 進行完整快照更新...")
    
    # 先取出當前資料作為比對
    cursor.execute("SELECT sale_id, quantity, returned_quantity FROM sales")
    current_map = {row[0]: (row[1], row[2]) for row in cursor.fetchall()}

    changed_count = 0
    update_sql = """
        UPDATE sales 
        SET quantity = %s, returned_quantity = %s
        WHERE sale_id = %s
    """
    update_batch = []
    for r in updated_records:
        sid = r['sale_id']
        cur_q, cur_r = current_map.get(sid, (None, None))
        if cur_q != r['quantity'] or cur_r != r['returned_quantity']:
            changed_count += 1
            update_batch.append((r['quantity'], r['returned_quantity'], sid))

    cursor.executemany(update_sql, update_batch)
    return changed_count

def run_pipeline():
    try:
        conn = get_connection()
        conn.autocommit = False
        cursor = conn.cursor()

        init_table(cursor)

        # 1. 匯入原始資料
        orig_file = os.path.join(os.path.dirname(__file__), 'sales_original.csv')
        orig_records = load_csv(orig_file)
        import_original_data(cursor, orig_records)
        conn.commit()

        # 2. 驗收原始資料
        print("[2/4] 驗收原始資料統計...")
        orig_stats = query_stats(cursor)
        print(f"    原始統計結果: {orig_stats}")
        assert orig_stats == EXPECTED_ORIGINAL, f"原始統計不符! 期待: {EXPECTED_ORIGINAL}, 得到: {orig_stats}"
        print("    [PASS] 原始資料驗收完全吻合!")

        # 3. 依 sale_id 更新快照
        updated_file = os.path.join(os.path.dirname(__file__), 'sales_updated.csv')
        updated_records = load_csv(updated_file)
        changed = update_snapshot(cursor, updated_records)
        conn.commit()

        # 4. 驗收更新後快照
        print("[4/4] 驗收更新後快照統計...")
        updated_stats = query_stats(cursor)
        print(f"    更新後統計結果: {updated_stats}, 異動筆數: {changed}")
        
        expected_check = {**EXPECTED_UPDATED}
        del expected_check['changed']
        assert updated_stats == expected_check, f"更新統計不符! 期待: {expected_check}, 得到: {updated_stats}"
        assert changed == EXPECTED_UPDATED['changed'], f"異動筆數不符! 期待: 240, 得到: {changed}"
        print("    [PASS] 更新後資料與 240 筆異動驗收完全吻合!")

        print("
==========================================")
        print(" pipeline.py 執行成功！所有驗收指標均通過。")
        print("==========================================")

    except Error as e:
        print(f"[ERROR] MySQL 執行錯誤: {e}", file=sys.stderr)
        if conn:
            conn.rollback()
        sys.exit(1)
    finally:
        if 'cursor' in locals() and cursor:
            cursor.close()
        if 'conn' in locals() and conn.is_connected():
            conn.close()

if __name__ == '__main__':
    run_pipeline()
