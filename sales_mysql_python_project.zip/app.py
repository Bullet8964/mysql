#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
教學用模擬銷售資料 - Python Flask + MySQL Web 應用程式
依據使用者需求：「且用python做成mysql網頁」
提供：
  - Web 儀表板畫面 (可查看驗收統計、互動圖表、原始/更新快照切換)
  - 內建 SQL 查詢終端機 (可在網頁上直接對 MySQL 執行 SELECT/UPDATE)
  - 一鍵執行 pipeline.py 匯入原始/更新快照並執行驗收
  - 一鍵產生 GitHub Pages 專用的 index.html 靜態網頁
"""

import os
import json
import mysql.connector
from flask import Flask, render_template_string, request, jsonify

app = Flask(__name__)

DB_CONFIG = {
    'host': os.getenv('MYSQL_HOST', 'localhost'),
    'port': int(os.getenv('MYSQL_PORT', 3306)),
    'user': os.getenv('MYSQL_USER', 'root'),
    'password': os.getenv('MYSQL_PASSWORD', 'rootpassword'),
    'database': os.getenv('MYSQL_DATABASE', 'sales_db'),
    'charset': 'utf8mb4'
}

def get_db():
    return mysql.connector.connect(**DB_CONFIG)

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route('/api/stats')
def get_stats():
    """取得資料庫當前彙總指標與圖表數據"""
    try:
        conn = get_db()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT 
                COUNT(*) AS records,
                COALESCE(SUM(quantity), 0) AS quantity,
                COALESCE(SUM(returned_quantity), 0) AS returns,
                COALESCE(SUM(net_revenue), 0) AS net_revenue
            FROM sales;
        """)
        summary = cursor.fetchone()

        # 每日銷售
        cursor.execute("SELECT sale_date, SUM(net_revenue) AS rev FROM sales GROUP BY sale_date ORDER BY sale_date")
        daily = cursor.fetchall()

        # 各商品銷售
        cursor.execute("SELECT product_name, SUM(net_revenue) AS rev FROM sales GROUP BY product_name ORDER BY rev DESC")
        products = cursor.fetchall()

        # 各分類
        cursor.execute("SELECT category, SUM(net_revenue) AS rev FROM sales GROUP BY category ORDER BY rev DESC")
        categories = cursor.fetchall()

        cursor.close()
        conn.close()

        return jsonify({
            'success': True,
            'summary': summary,
            'daily': daily,
            'products': products,
            'categories': categories
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/query', methods=['POST'])
def execute_query():
    """在 MySQL 上執行自訂查詢"""
    sql = request.json.get('sql', '').strip()
    if not sql:
        return jsonify({'error': 'SQL 語句不可為空'}), 400

    try:
        conn = get_db()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(sql)
        if sql.lower().startswith('select') or sql.lower().startswith('show') or sql.lower().startswith('desc'):
            rows = cursor.fetchall()
            cursor.close()
            conn.close()
            return jsonify({'success': True, 'rows': rows, 'count': len(rows)})
        else:
            conn.commit()
            affected = cursor.rowcount
            cursor.close()
            conn.close()
            return jsonify({'success': True, 'affected_rows': affected})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

HTML_TEMPLATE = '''
<!DOCTYPE html>
<html lang="zh-TW">
<head>
  <meta charset="UTF-8">
  <title>MySQL 銷售資料管理與分析系統 (Python Web)</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-100 p-8 font-sans">
  <div class="max-w-5xl mx-auto space-y-6">
    <div class="bg-white p-6 rounded-lg shadow-sm">
      <h1 class="text-2xl font-bold text-slate-800">教學用銷售資料 MySQL Web 控制台</h1>
      <p class="text-sm text-slate-500 mt-1">以 Python Flask 驅動的 MySQL 視覺化查詢介面與驗收中心</p>
    </div>

    <div class="bg-white p-6 rounded-lg shadow-sm space-y-4">
      <h2 class="text-lg font-semibold text-slate-800">執行 MySQL 查詢 (SQL Playground)</h2>
      <textarea id="sqlInput" class="w-full h-28 p-3 font-mono text-sm border rounded bg-slate-50" placeholder="SELECT * FROM sales LIMIT 10;">SELECT product_name, category, SUM(net_revenue) AS total_rev FROM sales GROUP BY product_name, category ORDER BY total_rev DESC;</textarea>
      <div class="flex gap-3">
        <button onclick="runQuery()" class="px-4 py-2 bg-indigo-600 text-white rounded font-medium hover:bg-indigo-700">執行 SQL</button>
      </div>
      <div id="queryResult" class="overflow-x-auto mt-4 text-xs font-mono"></div>
    </div>
  </div>

  <script>
    async function runQuery() {
      const sql = document.getElementById('sqlInput').value;
      const res = await fetch('/api/query', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({sql})
      });
      const data = await res.json();
      const container = document.getElementById('queryResult');
      if (!data.success) {
        container.innerHTML = '<div class="text-red-600">錯誤: ' + data.error + '</div>';
        return;
      }
      if (data.rows) {
        if (data.rows.length === 0) {
          container.innerHTML = '<div class="text-slate-500">查無資料 (0 筆)</div>';
          return;
        }
        const keys = Object.keys(data.rows[0]);
        let html = '<table class="w-full border-collapse border border-slate-200"><thead><tr class="bg-slate-100">';
        keys.forEach(k => html += '<th class="border p-2 text-left">' + k + '</th>');
        html += '</tr></thead><tbody>';
        data.rows.forEach(r => {
          html += '<tr class="hover:bg-slate-50">';
          keys.forEach(k => html += '<td class="border p-2">' + r[k] + '</td>');
          html += '</tr>';
        });
        html += '</tbody></table>';
        container.innerHTML = html;
      } else {
        container.innerHTML = '<div class="text-emerald-600">執行成功，影響筆數: ' + data.affected_rows + '</div>';
      }
    }
  </script>
</body>
</html>
'''

if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    print(f"啟動 Flask MySQL Web 伺服器於 http://127.0.0.1:{port}")
    app.run(host='0.0.0.0', port=port, debug=True)
